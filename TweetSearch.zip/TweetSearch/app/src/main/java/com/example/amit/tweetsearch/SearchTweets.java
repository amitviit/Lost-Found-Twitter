package com.example.amit.tweetsearch;

import android.Manifest;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.twitter.sdk.android.Twitter;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.TwitterApiClient;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.models.Coordinates;
import com.twitter.sdk.android.core.models.Search;
import com.twitter.sdk.android.core.models.Tweet;
import com.twitter.sdk.android.core.services.SearchService;
import com.twitter.sdk.android.tweetui.TweetViewAdapter;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;


public class SearchTweets extends AppCompatActivity implements LocationListener {

    private boolean endOfSearchResult;
    private boolean flagLoading;
    private static String searchQuery;
    private TweetViewAdapter adapter;
    private static String searchResultType = "recent";
    private int searchLimit = 20;
    private long maxID;
    ListView searchList;
    LocationManager locationManager;
    String provider;
//    Double currLat=28.078692;
//    Double currLng=-82.415610;

    double currLat;
    double currLng;
    List<Tweet> tweetsSortedByTime , temp;
    PriorityQueue<Tweet> tweetsSortedByLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Bundle bundle = getIntent().getExtras();
        searchQuery = bundle.getString("action");  // get user action from menu activity

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_tweets);
        TwitterSession session = Twitter.getSessionManager().getActiveSession();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        setProgressBarIndeterminateVisibility(true);
        handleIntent(getIntent());

        /* code to get current user location */

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        provider = locationManager.getBestProvider(new Criteria(), false);  // use default criteria

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(provider);  // get coarse location if fine location is unavailable

        if (location != null) {

            Log.i("Location Info", "Location achieved!");

        } else {

            Log.i("Location Info", "No location :(");
        }


        adapter = new TweetViewAdapter(SearchTweets.this);
        searchList = (ListView) findViewById(R.id.listView);
        searchList.setAdapter(adapter);

        TwitterApiClient twitterApiClient = TwitterCore.getInstance().getApiClient();
        final SearchService service = twitterApiClient.getSearchService();
        service.tweets(searchQuery, null, null, null, searchResultType, searchLimit, null, null, maxID,
                true, new Callback<Search>() {
                    @Override
                    public void success(Result<Search> result) {
                        setProgressBarIndeterminateVisibility(false);
                        tweetsSortedByTime = result.data.tweets;     //tweets is the list of tweets searched
                        temp = new ArrayList(tweetsSortedByTime);   // create a copy

                        adapter.getTweets().addAll(tweetsSortedByTime);
                        adapter.notifyDataSetChanged();
                        Log.d("Total Tweets: ", Integer.toString(tweetsSortedByTime.size()));

                        for (Tweet tweet : tweetsSortedByTime) {
                            try {
                                //  Log.d("Place: ", tweet.place.fullName);
                              //  Log.d("Latitude: ", Double.toString(tweet.coordinates.getLatitude()));
                               // Log.d("Longitude: ", Double.toString(tweet.coordinates.getLongitude()));
                                Log.d("Tweets: ", tweet.text);

                            } catch (Exception e) {
                                Log.d("****No Location", "*****");
                            }
                        }
                        try {
                            Log.d("CL in Search Tweets : ",String.valueOf(currLat) + String.valueOf(currLng));
                        }
                        catch (Exception e) {
                            Log.d("****No Location", "*****");
                        }

                        tweetsSortedByLocation = new PriorityQueue<>(10, new SortLocations(currLat, currLng));
                        tweetsSortedByLocation.addAll(temp);
                       // Collections.sort(tweetsSortedByLocation, new SortLocations(currLat, currLng));   // sort the list based on geolocation
                        // List after sorting
                        Log.d("Tweets: ", "after sorting");
                        for (Tweet tweet : tweetsSortedByLocation) {
                            Log.d("Tweets: ", tweet.text);
                        }


                        if (tweetsSortedByTime.size() > 0) {
                            maxID = tweetsSortedByTime.get(tweetsSortedByTime.size() - 1).id - 1;
                        } else {
                            endOfSearchResult = true;
                        }
                        flagLoading = false;
                    }

                    @Override
                    public void failure(TwitterException e) {
                        setProgressBarIndeterminateVisibility(false);
                        Toast.makeText(getApplicationContext(), "Failed to load tweets", Toast.LENGTH_SHORT).show();
                    }
                });

    }


    public void onSortByLocation(View view)    // called by Nearby button
    {
        temp.clear();
        temp.addAll(tweetsSortedByLocation);
        adapter.setTweets(temp);
        adapter.notifyDataSetChanged();
    }

    public void onSortByRecent(View view)       // called by Recent button
    {
        adapter.setTweets(tweetsSortedByTime);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        handleIntent(intent);
        super.onNewIntent(intent);
    }

    public void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            searchQuery = intent.getStringExtra(SearchManager.QUERY);
        }

        Log.d("Searcher", searchQuery);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(provider, 400, 1, this);   // refresh after 400 ms , sensitivity 1 meter

    }

    @Override
    protected void onPause() {
        super.onPause();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.removeUpdates(this);

    }

    @Override
    public void onLocationChanged(Location location) {// method called when user location is changed


       // currLat =(double)Math.round(location.getLatitude() * 100000d) / 100000d;
       // currLng =(double)Math.round(location.getLongitude() * 100000d) / 100000d;
        currLat = location.getLatitude();
        currLng = location.getLongitude();


       // Toast.makeText(getApplicationContext(), String.valueOf(currLat)+ String.valueOf(currLng),Toast.LENGTH_SHORT).show();

        Log.i("CL in location chg: Lat",String.valueOf(currLat));
        Log.i("CL in location chg: Lng",String.valueOf(currLng));
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public void getLocation(View view) {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = locationManager.getLastKnownLocation(provider);

        onLocationChanged(location);


    }
}
