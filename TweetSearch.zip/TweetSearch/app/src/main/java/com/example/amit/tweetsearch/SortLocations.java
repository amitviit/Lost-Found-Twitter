package com.example.amit.tweetsearch;


import android.util.Log;
import com.twitter.sdk.android.core.models.Tweet;
import java.util.Comparator;
import java.lang.Math.*;
/* Implements comparator class with generic type Tweet and sort based on distances from user location*/

public class SortLocations implements Comparator<Tweet> {
    double currLat;
    double currLng;

    public SortLocations(double currLat1, double currLng1) {
        currLat = currLat1;
        currLng = currLng1;
        try {
            Log.d("CL in sort Locations : ", String.valueOf(currLat)+ String.valueOf(currLng));
        }
        catch (Exception E) {
            Log.d("No coordinates", "");
        }
    }

    @Override
    public int compare(final Tweet tweet1, final Tweet tweet2) {
        double lat1 = 0.0, lon1 = 0.0, lat2 = 0.0, lon2 = 0.0, distanceToPlace1 = 0.0, distanceToPlace2 = 0.0,distance =0.0;
        try {
            lat1 = tweet1.coordinates.getLatitude();
            lon1 = tweet1.coordinates.getLongitude();

            lat2 = tweet2.coordinates.getLatitude();
            lon2 = tweet2.coordinates.getLongitude();

            distanceToPlace1 = distance(currLat, currLng, lat1, lon1);
          //  Log.d("Distance to Place 1 : ",String.valueOf(distanceToPlace1));
            distanceToPlace2 = distance(currLat, currLng, lat2, lon2);
         //   Log.d("Distance to Place 2 : ",String.valueOf(distanceToPlace2));
        } catch (Exception E) {
            Log.d("No coordinates", "");
        }
        distance =distanceToPlace1 - distanceToPlace2;
        Log.d("Distance : ",String.valueOf(distance));
        if (distanceToPlace1 < distanceToPlace2) {
            return 1;
        } else if (distanceToPlace1 > distanceToPlace2) {
            return -1;
        } else {
            return 0;
        }
    }

    public double distance(double fromLat, double fromLon, double toLat, double toLon) {
        double radius = 6378137.0;   // approximate Earth radius, *in meters*
        double deltaLat = toLat - fromLat;
        double deltaLon = toLon - fromLon;
        double angle = 2 * Math.asin(Math.sqrt(
                Math.pow(Math.sin(deltaLat / 2), 2) +
                        Math.cos(fromLat) * Math.cos(toLat) *
                                Math.pow(Math.sin(deltaLon / 2), 2)));
        double radxang = radius*angle;
        Log.d("Radius * Angle : ",String.valueOf(radxang));
        return radius * angle;
    }
}
